payroll
├── __pychache__
│
├── controllers
│   ├── __pycache__
│   ├── __init__.py
│   └── controllers.py
├── models
│   ├── __pycache__
│   ├── hr_bonus_benefits.py
│   ├── hr_contribution_accounts.py
│   ├── hr_employee.py
│   ├── hr_payroll_line.py
│   ├── hr_payroll.py
│   └── hr_updates.py
├── security
│   └── ir.model.access.csv
├── views
│   ├── hr_bonus_benefits_views.xml
│   ├── hr_contribution_accounts_views.xml
│   ├── hr_payroll_menu_views.xml
│   ├── hr_payroll_views.xml
│   └── hr_updates_views.xml
├── __init__.py
├── __manifest__.py
└── estructura_carpetas.md

