# -*- coding: utf-8 -*-

from . import hr_payroll,hr_employee,hr_accrued,hr_payroll_line,hr_payroll_events,hr_parameters,hr_payroll_settlement,hr_payroll_settlement_line
